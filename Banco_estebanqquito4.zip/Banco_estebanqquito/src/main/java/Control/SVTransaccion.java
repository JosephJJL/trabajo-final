package Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Modelo.Conexion;

@WebServlet("/transaccion")
public class SVTransaccion extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener los parámetros del formulario
        String numeroCuenta = request.getParameter("numero-cuenta");
        double cantidad = Double.parseDouble(request.getParameter("cantidad"));

        // Query para realizar la transacción
        String query = "UPDATE tb_cuentasusuario SET Saldo = Saldo + ? WHERE NumeroCuenta = ?";

        // Conexión a la base de datos
        Conexion conexion = new Conexion();
        Connection conn = null;
        try {
            conn = conexion.conectar();
            if (conn != null) {
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setDouble(1, cantidad);
                pstmt.setString(2, numeroCuenta);
                int rowsAffected = pstmt.executeUpdate();

                // Verificar si la transacción se realizó con éxito
                sendResponse(response, rowsAffected > 0);
            } else {
                // Manejo del caso en que la conexión es nula
                sendErrorResponse(response, "Error de conexión a la base de datos");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de errores de SQL
            sendErrorResponse(response, "Error del servidor");
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    // Manejo de errores al cerrar la conexión
                }
            }
        }
    }

    private void sendResponse(HttpServletResponse response, boolean success) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        if (success) {
            out.println("{\"message\": \"Transacción exitosa\"}");
        } else {
            sendErrorResponse(response, "Error al procesar la transacción");
        }
    }

    private void sendErrorResponse(HttpServletResponse response, String errorMessage) throws IOException {
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.println("{\"error\": \"" + errorMessage + "\"}");
    }
}
