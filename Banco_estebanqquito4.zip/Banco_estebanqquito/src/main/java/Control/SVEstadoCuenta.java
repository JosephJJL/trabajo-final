package Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONObject; 
import Modelo.Conexion;

@WebServlet("/estadoCuenta")
public class SVEstadoCuenta extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener la ID de usuario almacenada en la sesión
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            // Si no hay una sesión activa o la ID de usuario no está en la sesión, enviar código de estado UNAUTHORIZED
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }
        int userId = (int) session.getAttribute("user_id");
        System.out.println("User ID from session: " + userId); // Línea de depuración

        // Conexión a la base de datos y consulta para obtener el estado de cuenta
        try (Connection conn = Conexion.conectar()) {
            String estadoCuenta = obtenerEstadoCuenta(conn, userId);
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            JSONObject jsonResponse = new JSONObject();

            if (estadoCuenta != null) {
                // Si se encontró el estado de cuenta, enviarlo como respuesta
                jsonResponse.put("estadoCuenta", estadoCuenta);
            } else {
                // Si el estado de cuenta no se encontró, enviar respuesta de error
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                jsonResponse.put("error", "Estado de cuenta no encontrado para el usuario");
            }
            out.println(jsonResponse.toString());
            out.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de errores
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("error", "Error del servidor");
            out.println(jsonResponse.toString());
            out.close();
        }
    }

    private String obtenerEstadoCuenta(Connection conn, int userId) throws SQLException {
        // Consulta para obtener el estado de cuenta del usuario por su ID_Usuario
        String query = "SELECT Estado_Cuenta FROM Cuenta WHERE ID_Usuario = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String estadoCuenta = rs.getString("Estado_Cuenta");
                    System.out.println("Estado de cuenta obtenido: " + estadoCuenta); // Línea de depuración
                    return estadoCuenta;
                }
            }
        }
        return null; // Devuelve null si el estado de cuenta no se encuentra
    }
}
