package Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Modelo.Conexion;

@WebServlet("/aplicarTasaInteres")
public class SVTasaInteres extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener los parámetros del formulario
        String accountNumber = request.getParameter("accountNumber");
        double interestRate = Double.parseDouble(request.getParameter("interestRate"));

        // Aplicar la tasa de interés a la cuenta
        boolean success = applyInterestRate(accountNumber, interestRate);

        // Preparar la respuesta JSON
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        if (success) {
            out.println("{\"message\": \"Se ha asignado una tasa de interés de " + interestRate + "% a la cuenta " + accountNumber + ".\"}");
        } else {
            out.println("{\"error\": \"Error al aplicar la tasa de interés.\"}");
        }
    }

    private boolean applyInterestRate(String accountNumber, double interestRate) {
        // Query para actualizar la tasa de interés en la base de datos
        String query = "UPDATE Cuenta SET Tasa_Interes = ? WHERE Numero_Cuenta = ?";

        // Conexión a la base de datos
        try (Connection conn = Conexion.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, interestRate);
            pstmt.setString(2, accountNumber);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
