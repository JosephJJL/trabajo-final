package Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Modelo.Conexion; // Importa la clase Conexion

@WebServlet("/deposito")
public class SVDeposito extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accountNumber = request.getParameter("accountNumber");
        double amount = Double.parseDouble(request.getParameter("amount"));

        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = Conexion.conectar(); // Utiliza la clase Conexion para establecer la conexión
            if (conn != null) {
                // Actualizar el saldo en la cuenta
                String query = "UPDATE Cuenta SET Saldo = Saldo + ? WHERE ID_Cuenta = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setDouble(1, amount);
                pstmt.setString(2, accountNumber);
                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    // Éxito
                    sendResponse(response, "Depósito exitoso");
                } else {
                    sendErrorResponse(response, "No se pudo completar el depósito");
                }
            } else {
                sendErrorResponse(response, "Error al conectar a la base de datos");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            sendErrorResponse(response, "Error del servidor: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendResponse(HttpServletResponse response, String message) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.println("{\"message\": \"" + message + "\"}");
        out.close();
    }

    private void sendErrorResponse(HttpServletResponse response, String errorMessage) throws IOException {
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.println("{\"error\": \"" + errorMessage + "\"}");
        out.close();
    }
}
