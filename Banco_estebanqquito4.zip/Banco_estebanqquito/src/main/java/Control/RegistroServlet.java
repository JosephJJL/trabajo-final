package Control;

import Modelo.Conexion;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registro")
public class RegistroServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener los parámetros del formulario
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String correoElectronico = request.getParameter("correoElectronico");
        String contraseña = request.getParameter("password");

        // Conexión a la base de datos
        Conexion conexion = new Conexion();
        Connection conn = conexion.conectar();

        // Query para insertar los datos en la base de datos
        String query = "INSERT INTO Usuario (Nombre, Apellido, CorreoElectronico, Contraseña) VALUES (?, ?, ?, ?)";

        try {
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            pstmt.setString(3, correoElectronico);
            pstmt.setString(4, contraseña);
            int filasInsertadas = pstmt.executeUpdate();

            if (filasInsertadas > 0) {
                // Commit de la transacción
                conn.commit();
                // Envía una respuesta al cliente
                PrintWriter out = response.getWriter();
                out.println("Registro exitoso");
            } else {
                PrintWriter out = response.getWriter();
                out.println("Error al registrar el usuario");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de errores SQL
            PrintWriter out = response.getWriter();
            out.println("Error al registrar el usuario: " + e.getMessage());
        } finally {
            // Cerrar la conexión después de usarla solo si se insertaron datos correctamente
            if (conn != null) {
                conexion.desconectar();
            }
        }
    }
}
