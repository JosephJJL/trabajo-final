package Control;

import Modelo.Conexion;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String correoElectronico = request.getParameter("login-correo");
        String contraseña = request.getParameter("login-password");

        // Realiza la validación de credenciales
        try (Connection conn = Conexion.conectar()) {
            int userId = getUserId(conn, correoElectronico, contraseña); // Obtener el ID_Usuario
            if (userId != -1) { // Si se encuentra el usuario
                System.out.println("Inicio de sesión exitoso");
                HttpSession session = request.getSession();
                session.setAttribute("user_id", userId); // Guardar el ID_Usuario en la sesión
                response.sendRedirect("segunda_pagina.jsp"); // Redirige al usuario a la segunda página si las credenciales son válidas
            } else {
                System.out.println("Credenciales inválidas");
                response.sendRedirect("index.html"); // Redirige al usuario a la página de inicio de sesión si las credenciales son inválidas
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    private int getUserId(Connection conn, String correoElectronico, String contraseña) throws SQLException {
        // Consulta la base de datos para obtener el ID_Usuario
        String sql = "SELECT ID_Usuario FROM Usuario WHERE CorreoElectronico = ? AND Contraseña = ?";
        System.out.println("Consulta SQL: " + sql); // Imprime la consulta SQL
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, correoElectronico);
            statement.setString(2, contraseña);

            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    return result.getInt("ID_Usuario"); // Devuelve el ID_Usuario si se encuentra
                } else {
                    return -1; // Devuelve -1 si no se encuentra ningún usuario con las credenciales dadas
                }
            }
        }
    }
}
