package Control;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Modelo.Conexion; // Importa la clase Conexion

@WebServlet("/conversion")
public class SVConversionMoneda extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        double amount = Double.parseDouble(request.getParameter("amount"));
        double exchangeRate = Double.parseDouble(request.getParameter("exchangeRate"));

        // Realizar la conversión
        double convertedAmount = amount * exchangeRate;

        // Preparar la respuesta JSON
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.println("{\"convertedAmount\": " + convertedAmount + "}");

        out.close();
    }
}
