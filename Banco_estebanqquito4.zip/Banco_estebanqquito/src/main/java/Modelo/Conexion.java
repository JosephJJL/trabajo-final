package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static Connection conn;
    private static final String host = "localhost";
    private static final String port = "3306";
    private static final String dbName = "base_de_datos_banco";
    private static final String username = "root";
    private static final String password = "1234";
    
    public static Connection conectar() {
        try {
            // Cargar el driver de MariaDB
            Class.forName("org.mariadb.jdbc.Driver");
            
            // URL de conexión
            String url = "jdbc:mariadb://" + host + ":" + port + "/" + dbName;
            
            // Establecer la conexión
            conn = DriverManager.getConnection(url, username, password);
            
            if (conn != null) {
                System.out.println("Conexión exitosa a la base de datos");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return conn;
    }
    
    public static void desconectar() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Conexión cerrada");
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());     
        }
    }
    
    public static void main(String[] args) {
        Conexion.conectar(); // Intenta establecer la conexión al crear un objeto
        Conexion.desconectar(); // Cierra la conexión después de usarla
    }
}
